# 42 MD BOT command catalogue

This catalogue combines common feature families documented by public WhatsApp MD bot projects with the 42 MD BOT command set. It does **not** claim every command below exists in every named bot. Public references are listed at the end. The `Implemented` list means the current project handler contains the command; `Planned/integration required` means it needs more code, permissions, persistent storage, or a provider API before it should be advertised as working.

## Implemented in this build

- **General:** `.menu`, `.help`, `.alive`, `.ping`, `.owner`, `.admin`, `.info`, `.jid`, `.chatid`
- **AI:** `.ai <question>` (requires a private `OPENAI_API_KEY`; the exposed key supplied in chat must not be used)
- **Stickers/media:** `.sticker`, `.s` (reply to/send an image)
- **Owner/profile:** `.setbotpic`, `.setbotpp`, `.setbotprofile`, `.setbotname`
- **Group:** `.groupinfo`, `.admins`, `.tagall`, `.kick`, `.promote`, `.demote`, `.antilink on|off`
- **Fun:** `.joke`, `.quote`, `.flip`, `.roll [sides]`, `.rps rock|paper|scissors`
- **Utilities:** `.calc`, `.math`, `.base64 encode|decode <text>`, `.morse encode|decode <text>`, `.password [length]`

## Planned / integration required

### Information and help
`.support`, `.report`, `.feedback`, `.privacy`, `.terms`, `.updates`, `.runtime`, `.uptime`, `.stats`, `.system`, `.about`, `.repo`, `.source`, `.donate`, `.commands`, `.help <category>`

### Media and conversion
`.toimg`, `.tovideo`, `.togif`, `.tomp3`, `.toaudio`, `.tourl`, `.take`, `.steal`, `.textsticker`, `.ttp`, `.attp`, `.emojimix`, `.meme`, `.wanted`, `.wasted`, `.blur`, `.enhance`, `.removebg`, `.ocr`, `.readqr`, `.qr`, `.logo`, `.neon`, `.glitch`, `.poster`

### AI and language
`.gpt`, `.ask`, `.imagine`, `.analyze`, `.vision`, `.summarize`, `.translate`, `.tts`, `.speak`, `.transcribe`, `.code`, `.debug`, `.story`, `.poem`, `.search`, `.explain`, `.character`, `.clearchat`

### Downloads and music
`.play`, `.song`, `.music`, `.ytmp3`, `.ytmp4`, `.video`, `.youtube`, `.tiktok`, `.tiktokaudio`, `.instagram`, `.facebook`, `.twitter`, `.threads`, `.spotify`, `.soundcloud`, `.pinterest`, `.mediafire`, `.gitclone`, `.lyrics`, `.bass`, `.nightcore`, `.slow`, `.speed`, `.reverse`, `.audioeffect`

### Group moderation and automation
`.members`, `.add`, `.link`, `.grouplink`, `.revoke`, `.setname`, `.setdesc`, `.setpp`, `.welcome`, `.setwelcome`, `.goodbye`, `.setgoodbye`, `.antispam`, `.antibadword`, `.warn`, `.warnings`, `.resetwarn`, `.mute`, `.unmute`, `.lock`, `.unlock`, `.poll`, `.vote`, `.rules`, `.setrules`, `.filter`, `.delete`, `.groupstats`, `.hidetag`, `.tagadmins`, `.autorespond`, `.setauto`, `.delauto`, `.schedule`, `.afk`, `.back`

### Fun and games
`.fact`, `.riddle`, `.trivia`, `.quiz`, `.truth`, `.dare`, `.8ball`, `.tictactoe`, `.hangman`, `.ship`, `.aura`, `.compliment`, `.hug`, `.kiss`, `.slap`, `.pat`, `.dance`, `.highfive`, `.daily`, `.profile`, `.leaderboard`, `.rank`, `.work`, `.balance`, `.shop`

### Search and utilities
`.google`, `.wiki`, `.define`, `.weather`, `.news`, `.time`, `.currency`, `.convert`, `.country`, `.ip`, `.shorten`, `.remind`, `.getpp`, `.shazam`, `.screenshot`, `.scanurl`, `.tempmail`, `.getmetadata`, `.ssweb`, `.calc`, `.calage`, `.getjid`

### Owner and dashboard controls
`.settings`, `.setprefix`, `.public`, `.private`, `.mode`, `.restart`, `.shutdown`, `.broadcast`, `.ban`, `.unban`, `.banlist`, `.block`, `.unblock`, `.setbio`, `.setlang`, `.settheme`, `.autoread`, `.autoreact`, `.alwaysonline`, `.antidelete`, `.anticall`, `.adminpanel`, `.logs`, `.maintenance`, `.plugins`, `.backup`, `.restore`

**Deliberately excluded by default:** `.eval` / `.exec` (arbitrary code execution is unsafe), spam/bulk messaging, credential/session stealing, and bypasses of platform restrictions.

## API and deployment notes

- AI: `OPENAI_API_KEY`, `OPENAI_MODEL` (server environment only).
- Media upload/conversion: Sharp is included; FFmpeg may be needed for video/audio formats.
- Search/weather/currency/translation/TTS/image generation/downloads: choose an appropriate provider, review its terms and cost, and add its API key as a private environment variable. No provider key can be conjured or enabled without an account/credentials.
- Group commands require the bot to be a group admin for actions such as remove/promote/demote. Use permission checks and rate limits.
- The `.setbotpic` command changes the linked bot account's **global** profile picture. By default, only the configured owner can use it. The dashboard can enable public changes, but that is risky and disabled by default.

## Public references consulted

- Ghost-MD: https://github.com/Blvckcastro/Ghost-Md
- Queen-MD: https://github.com/Nimuzzz/Queen-MD
- Rimuru/Tensura reference project: https://github.com/rizuruu/Rimuru
- Queen Elisa MD command aliases: https://app.unpkg.com/queen-elisa-md@4.0.2/files/allcmd.json
- Queen Sia MD: https://github.com/QUEENSIA/QUEEN-SIA-MD
