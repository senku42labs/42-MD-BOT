require('dotenv').config();
const fs = require('fs');
const path = require('path');
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const multer = require('multer');
const pino = require('pino');
const QRCode = require('qrcode');
const sharp = require('sharp');
const OpenAI = require('openai');
const {
  default: makeWASocket, useMultiFileAuthState, DisconnectReason,
  fetchLatestBaileysVersion, downloadContentFromMessage, jidNormalizedUser
} = require('@whiskeysockets/baileys');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const DATA_DIR = process.env.DATA_DIR || '.data';
const AUTH_DIR = path.join(DATA_DIR, 'auth');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');
const PROFILE_DIR = path.join(DATA_DIR, 'profile');
fs.mkdirSync(AUTH_DIR, { recursive: true });
fs.mkdirSync(PROFILE_DIR, { recursive: true });
function readSavedSettings() { try { return JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')); } catch { return {}; } }
const savedSettings = readSavedSettings();
function persistSettings() { fs.writeFileSync(SETTINGS_FILE, JSON.stringify({ botName: state.botName, prefix: state.prefix, allowPublicProfileChange: state.allowPublicProfileChange }, null, 2), { mode: 0o600 }); }
const logger = pino({ level: process.env.LOG_LEVEL || 'info' });
const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;
const state = {
  sock: null, qr: null, pairingCode: null, connected: false, connecting: false,
  lastConnectedAt: null, lastError: null,
  botName: savedSettings.botName || process.env.BOT_NAME || '42 MD BOT', prefix: savedSettings.prefix || process.env.PREFIX || '.',
  allowPublicProfileChange: Object.prototype.hasOwnProperty.call(savedSettings, 'allowPublicProfileChange') ? savedSettings.allowPublicProfileChange === true : process.env.ALLOW_PUBLIC_PROFILE_CHANGE === 'true',
  antiLink: new Map(), startedAt: Date.now()
};

const app = express();
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '1mb' }));
app.use(session({
  name: '42md.sid',
  secret: process.env.ADMIN_SESSION_SECRET || 'development-only-change-this-secret',
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'strict', secure: process.env.NODE_ENV === 'production', maxAge: 8 * 60 * 60 * 1000 }
}));
const adminUser = process.env.ADMIN_USERNAME || 'admin';
const adminPass = process.env.ADMIN_PASSWORD || '';
const profileUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 }, fileFilter: (_req, file, cb) => cb(null, /^image\/(png|jpeg|webp)$/.test(file.mimetype)) });
function requireAdmin(req, res, next) {
  if (req.session && req.session.admin === true) return next();
  return res.status(401).json({ error: 'Sign in required' });
}
app.get('/health', (_req, res) => res.json({ ok: true, service: '42-md-bot' }));
app.get('/', (req, res) => res.send(req.session?.admin ? dashboardHtml() : loginHtml()));
app.post('/login', (req, res) => {
  const { username, password } = req.body || {};
  if (!adminPass || adminPass.length < 12 || !process.env.ADMIN_SESSION_SECRET || process.env.ADMIN_SESSION_SECRET.length < 32) {
    return res.status(503).json({ error: 'Configure ADMIN_PASSWORD (12+ characters) and ADMIN_SESSION_SECRET (32+ characters) first.' });
  }
  if (username !== adminUser || password !== adminPass) return res.status(401).json({ error: 'Invalid username or password' });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: 'Could not create session' });
    req.session.admin = true;
    res.json({ ok: true });
  });
});
app.post('/logout', requireAdmin, (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get('/api/status', requireAdmin, (_req, res) => res.json({
  botName: state.botName, prefix: state.prefix, connected: state.connected, connecting: state.connecting,
  qrAvailable: Boolean(state.qr), lastConnectedAt: state.lastConnectedAt, lastError: state.lastError,
  uptimeSeconds: Math.floor((Date.now() - state.startedAt) / 1000), aiEnabled: Boolean(openai),
  ownerConfigured: Boolean(process.env.OWNER_NUMBER), allowPublicProfileChange: state.allowPublicProfileChange, profilePictureConfigured: fs.existsSync(path.join(PROFILE_DIR, 'bot-profile.webp'))
}));
app.get('/api/qr', requireAdmin, async (_req, res) => {
  if (!state.qr) return res.status(404).json({ error: 'QR not available yet. Wait a moment or use pairing code.' });
  res.type('png').send(await QRCode.toBuffer(state.qr, { width: 320, margin: 2 }));
});
app.post('/api/pairing', requireAdmin, async (req, res) => {
  const number = String(req.body?.phone || '').replace(/\D/g, '');
  if (number.length < 8 || number.length > 15) return res.status(400).json({ error: 'Enter your own number in international format, digits only.' });
  try {
    if (!state.sock) await startWhatsApp();
    if (state.connected) return res.status(400).json({ error: 'Already connected. Use Linked devices instead.' });
    const code = await state.sock.requestPairingCode(number);
    state.pairingCode = code;
    res.json({ ok: true, code });
  } catch (err) {
    state.lastError = err.message;
    res.status(500).json({ error: 'Pairing code failed. Try QR linking and check server logs.' });
  }
});
app.get('/api/settings', requireAdmin, (_req, res) => res.json({ botName: state.botName, prefix: state.prefix, allowPublicProfileChange: state.allowPublicProfileChange }));
app.post('/api/settings', requireAdmin, async (req, res) => {
  const botName = String(req.body?.botName || '').trim().slice(0, 40);
  const prefix = String(req.body?.prefix || '').trim().slice(0, 3);
  if (!botName || !prefix) return res.status(400).json({ error: 'Bot name and prefix are required.' });
  state.botName = botName; state.prefix = prefix;
  state.allowPublicProfileChange = req.body?.allowPublicProfileChange === true;
  persistSettings();
  if (state.sock && state.connected) { try { await state.sock.updateProfileName(botName); } catch (e) { logger.warn({ err: e.message }, 'Could not update WhatsApp profile name'); } }
  res.json({ ok: true, botName, prefix, allowPublicProfileChange: state.allowPublicProfileChange });
});
app.post('/api/profile-picture', requireAdmin, profileUpload.single('picture'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Upload a PNG, JPEG, or WebP image up to 5 MB.' });
  if (!state.sock || !state.connected || !state.sock.user?.id) return res.status(409).json({ error: 'Connect WhatsApp before changing the profile picture.' });
  try {
    const buffer = await sharp(req.file.buffer).resize(640, 640, { fit: 'cover' }).webp({ quality: 88 }).toBuffer();
    fs.writeFileSync(path.join(PROFILE_DIR, 'bot-profile.webp'), buffer, { mode: 0o600 });
    await state.sock.updateProfilePicture(state.sock.user.id, buffer);
    res.json({ ok: true, message: 'WhatsApp profile picture updated.' });
  } catch (err) { logger.error({ err }, 'Profile picture update failed'); res.status(500).json({ error: 'Profile picture update failed. Check server logs and WhatsApp connection.' }); }
});

const css = `:root{color-scheme:dark;--bg:#070b0a;--panel:#101816;--line:#263a32;--green:#47ff9a;--muted:#9ab2a6}*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at top,#10271d,#070b0a 55%);color:#effff5;font:15px system-ui,Segoe UI,sans-serif;min-height:100vh}header{display:flex;justify-content:space-between;align-items:center;padding:18px max(20px,calc((100% - 1100px)/2));border-bottom:1px solid var(--line);background:#07100de8}.brand{display:flex;gap:12px;align-items:center}.brand small{display:block}.logo{width:64px;height:64px;border:2px solid var(--green);border-radius:18px;display:grid;place-items:center;color:var(--green);font-size:26px;font-weight:900;box-shadow:0 0 25px #47ff9a22}.logo.small{width:42px;height:42px;border-radius:12px;font-size:18px}.wrap{max-width:1100px;margin:28px auto;padding:0 18px}.panel{background:linear-gradient(145deg,#111b17,#0b110f);border:1px solid var(--line);border-radius:18px;padding:22px;box-shadow:0 12px 38px #0003}.hero{display:flex;justify-content:space-between;align-items:center;gap:16px;margin-bottom:18px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:18px}h1{margin:4px 0 8px;font-size:clamp(26px,4vw,38px)}h2{margin-top:0}h3{margin-bottom:6px}.muted{color:var(--muted)}.eyebrow{font-size:11px;letter-spacing:3px;color:var(--green);font-weight:800}.status{padding:10px 14px;border:1px solid #4b4b2b;border-radius:999px;color:#ffe6a4;white-space:nowrap}.status.good{border-color:#236b48;color:var(--green)}label{display:block;margin:14px 0;color:#c8dbd0;font-size:13px}input{display:block;width:100%;padding:12px 13px;margin-top:6px;background:#070c0a;color:white;border:1px solid #2a4438;border-radius:10px;font:inherit;outline:none}input:focus{border-color:var(--green)}button{border:0;border-radius:10px;padding:12px 16px;background:var(--green);color:#062013;font-weight:800;cursor:pointer}button:hover{filter:brightness(1.07)}button.secondary{background:#182a22;color:#dfffee;border:1px solid #2e5140}.qrwrap{display:none;text-align:center;padding:15px;background:#fff;border-radius:12px;margin:14px 0;color:#182019}.qrwrap img{width:260px;max-width:100%}.qrwrap p{color:#43574b}hr{border:0;border-top:1px solid var(--line);margin:22px 0}.msg{color:var(--green);overflow-wrap:anywhere}.commands{display:grid;grid-template-columns:max-content 1fr;gap:10px 16px;align-items:center}.commands code{background:#0a2418;color:var(--green);padding:5px 8px;border-radius:6px}.foot{text-align:center;font-size:12px;margin:22px}.login{width:min(420px,calc(100% - 30px));margin:10vh auto;text-align:center}.login form{text-align:left}.login button{width:100%;margin-top:8px}dl{display:grid;grid-template-columns:1fr 1.3fr;gap:10px;font-size:13px}dt{color:var(--muted)}dd{margin:0;overflow-wrap:anywhere}@media(max-width:760px){.grid{grid-template-columns:1fr}.hero{align-items:flex-start;flex-direction:column}.commands{grid-template-columns:1fr}.commands span{margin-bottom:7px}}`;
function loginHtml() { return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>42 MD BOT · Sign in</title><style>${css}</style></head><body><main class="login panel"><div class="logo">42</div><h1>42 MD BOT</h1><p class="muted">Secure owner dashboard</p><form id="login"><label>Username<input name="username" autocomplete="username" required></label><label>Password<input name="password" type="password" autocomplete="current-password" required></label><button>Sign in</button><p id="msg" class="msg"></p></form></main><script>document.querySelector('#login').onsubmit=async e=>{e.preventDefault();let f=new FormData(e.target);let r=await fetch('/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:f.get('username'),password:f.get('password')})});let d=await r.json();if(r.ok)location.reload();else document.querySelector('#msg').textContent=d.error||'Sign in failed';};</script></body></html>`; }
function dashboardHtml() { return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>42 MD BOT Dashboard</title><style>${css}</style></head><body><header><div class="brand"><span class="logo small">42</span><div><b>42 MD BOT</b><small class="muted">Control center</small></div></div><button class="secondary" id="logout">Log out</button></header><main class="wrap"><section class="hero panel"><div><p class="eyebrow">WHATSAPP MD SYSTEM</p><h1>Bot dashboard</h1><p class="muted">Connect WhatsApp, manage settings and monitor status.</p></div><div id="status" class="status">Checking…</div></section><div class="grid"><section class="panel"><h2>WhatsApp connection</h2><p id="connection" class="muted">Checking connection…</p><div id="qrwrap" class="qrwrap"><img id="qr" alt="WhatsApp QR code"><p>WhatsApp → Linked devices → Link a device</p></div><button id="refresh" class="secondary">Refresh status / QR</button><hr><h3>Pair with phone number</h3><p class="muted">Use your own number with country code, digits only.</p><form id="pair"><label>Phone number<input name="phone" placeholder="263771234567" inputmode="numeric" required></label><button>Request pairing code</button></form><p id="pairresult" class="msg"></p></section><section class="panel"><h2>Bot settings</h2><form id="settings"><label>Bot name<input name="botName" maxlength="40" required></label><label>Command prefix<input name="prefix" maxlength="3" required></label><label><input style="display:inline;width:auto;margin-right:8px" name="allowPublicProfileChange" type="checkbox">Allow any chat user to change the bot profile picture with .setbotpic (not recommended)</label><button>Save settings</button></form><p id="settingsmsg" class="msg"></p><hr><h3>Bot profile picture</h3><form id="avatar"><label>Choose PNG, JPEG, or WebP image (max 5 MB)<input name="picture" type="file" accept="image/png,image/jpeg,image/webp" required></label><button>Upload and apply picture</button></form><p id="avatarm" class="msg"></p><hr><h2>System status</h2><dl id="details"></dl></section></div><section class="panel"><h2>Command guide</h2><div class="commands"><code>.menu</code><span>Show all commands</span><code>.alive</code><span>Bot status</span><code>.sticker</code><span>Reply to an image to create a sticker</span><code>.ai question</code><span>Ask the optional AI assistant</span><code>.tagall</code><span>Mention group members (admins only)</span><code>.kick @user</code><span>Remove a mentioned member (admins only)</span><code>.antilink on/off</code><span>Toggle basic group link warning</span><code>.rps rock</code><span>Play rock-paper-scissors</span></div></section><p class="foot muted">Keep this dashboard private. Anyone who controls it can control your linked bot.</p></main><script>
async function api(url,opts={}){let r=await fetch(url,{...opts,headers:{'Content-Type':'application/json',...(opts.headers||{})}});let d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'Request failed');return d}
async function refresh(){try{let s=await api('/api/status');document.querySelector('#status').textContent=s.connected?'● Connected':s.connecting?'◌ Connecting':'○ Disconnected';document.querySelector('#status').className='status '+(s.connected?'good':'');document.querySelector('#connection').textContent=s.connected?'WhatsApp is connected. Keep the service running.':s.qrAvailable?'Scan the QR code below to link WhatsApp.':'Waiting for a QR code or pairing code.';if(s.qrAvailable&&!s.connected){document.querySelector('#qr').src='/api/qr?t='+Date.now();document.querySelector('#qrwrap').style.display='block'}else document.querySelector('#qrwrap').style.display='none';document.querySelector('#details').innerHTML=[['AI assistant',s.aiEnabled?'Enabled':'Disabled — add OPENAI_API_KEY'],['Owner number',s.ownerConfigured?'Configured':'Not configured'],['Command prefix',s.prefix],['Uptime',Math.floor(s.uptimeSeconds/60)+' min'],['Last connection',s.lastConnectedAt||'Not connected yet'],['Last error',s.lastError||'None']].map(x=>'<dt>'+x[0]+'</dt><dd>'+x[1]+'</dd>').join('');let st=await api('/api/settings');document.querySelector('[name=botName]').value=st.botName;document.querySelector('[name=prefix]').value=st.prefix;document.querySelector('[name=allowPublicProfileChange]').checked=st.allowPublicProfileChange}catch(e){document.querySelector('#connection').textContent=e.message}}
document.querySelector('#refresh').onclick=refresh;document.querySelector('#logout').onclick=async()=>{await api('/logout',{method:'POST'});location.reload()};
document.querySelector('#pair').onsubmit=async e=>{e.preventDefault();let phone=new FormData(e.target).get('phone');let p=document.querySelector('#pairresult');p.textContent='Requesting…';try{let d=await api('/api/pairing',{method:'POST',body:JSON.stringify({phone})});p.textContent='Pairing code: '+d.code+' — enter it in WhatsApp Linked devices.'}catch(err){p.textContent=err.message}};
document.querySelector('#settings').onsubmit=async e=>{e.preventDefault();let f=new FormData(e.target);let p=document.querySelector('#settingsmsg');try{await api('/api/settings',{method:'POST',body:JSON.stringify({botName:f.get('botName'),prefix:f.get('prefix'),allowPublicProfileChange:f.get('allowPublicProfileChange')==='on'})});p.textContent='Settings saved.';refresh()}catch(err){p.textContent=err.message}};document.querySelector('#avatar').onsubmit=async e=>{e.preventDefault();let p=document.querySelector('#avatarm');try{let r=await fetch('/api/profile-picture',{method:'POST',body:new FormData(e.target)});let d=await r.json();if(!r.ok)throw Error(d.error||'Upload failed');p.textContent=d.message;e.target.reset()}catch(err){p.textContent=err.message}};refresh();setInterval(refresh,12000);
</script></body></html>`; }

async function streamToBuffer(stream) { const chunks = []; for await (const chunk of stream) chunks.push(chunk); return Buffer.concat(chunks); }
async function imageBufferFromMessage(msg) {
  const m = msg.message || {};
  let node = m.imageMessage || m.stickerMessage;
  let kind = m.imageMessage ? 'image' : (m.stickerMessage ? 'sticker' : null);
  const quoted = m.extendedTextMessage?.contextInfo?.quotedMessage;
  if (!node && quoted) { node = quoted.imageMessage || quoted.stickerMessage; kind = quoted.imageMessage ? 'image' : (quoted.stickerMessage ? 'sticker' : null); }
  if (!node || !kind) return null;
  return streamToBuffer(await downloadContentFromMessage(node, kind));
}
function getText(msg) {
  const m = msg.message || {};
  return m.conversation || m.extendedTextMessage?.text || m.imageMessage?.caption || m.videoMessage?.caption || m.documentMessage?.caption || m.buttonsResponseMessage?.selectedButtonId || m.listResponseMessage?.singleSelectReply?.selectedRowId || '';
}
function senderNumber(jid) { return (jid || '').split('@')[0].split(':')[0]; }
function isOwner(jid) { const owner = (process.env.OWNER_NUMBER || '').replace(/\D/g, ''); return Boolean(owner) && senderNumber(jid) === owner; }
async function isGroupAdmin(sock, jid, sender) {
  try { const metadata = await sock.groupMetadata(jid); const p = metadata.participants.find(x => jidNormalizedUser(x.id) === jidNormalizedUser(sender)); return Boolean(p?.admin); } catch { return false; }
}
const menuText = () => `╭━━━〔 *${state.botName}* 〕━━━╮\n│ Prefix: ${state.prefix}\n│\n├─ *GENERAL*\n│ ${state.prefix}menu • ${state.prefix}help\n│ ${state.prefix}alive • ${state.prefix}ping\n│ ${state.prefix}owner • ${state.prefix}info • ${state.prefix}jid\n├─ *MEDIA & AI*\n│ ${state.prefix}sticker • ${state.prefix}toimg • ${state.prefix}setbotpic\n│ ${state.prefix}ai <question> • ${state.prefix}translate <lang> <text>\n├─ *GROUP TOOLS*\n│ ${state.prefix}groupinfo • ${state.prefix}admins • ${state.prefix}tagall\n│ ${state.prefix}kick @user • ${state.prefix}promote @user • ${state.prefix}demote @user\n│ ${state.prefix}antilink on/off • ${state.prefix}rules\n├─ *TOOLS*\n│ ${state.prefix}calc <expression> • ${state.prefix}base64 encode/decode <text>\n│ ${state.prefix}password [length] • ${state.prefix}morse encode/decode <text>\n├─ *FUN*\n│ ${state.prefix}joke • ${state.prefix}quote • ${state.prefix}flip • ${state.prefix}roll\n│ ${state.prefix}rps rock|paper|scissors\n╰━━━━━━━━━━━━━━━━━━━━╯\nSome download, image-generation, and search commands need separate API integrations.`;
const jokes = ['Why do programmers prefer dark mode? Because light attracts bugs.', 'I told my computer I needed a break. It said: no problem, I will go to sleep.', 'There are 10 kinds of people: those who understand binary and those who do not.'];
const quotes = ['Great things are done by a series of small things brought together. — Vincent van Gogh', 'It always seems impossible until it is done. — Nelson Mandela', 'The secret of getting ahead is getting started. — Mark Twain'];
async function handleCommand(sock, msg, body) {
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || jid;
  const isGroup = jid.endsWith('@g.us');
  const text = body.trim();
  const prefix = state.prefix;
  if (!text.startsWith(prefix)) return;
  const [raw, ...args] = text.slice(prefix.length).trim().split(/\s+/);
  const cmd = (raw || '').toLowerCase(); const arg = args.join(' ');
  if (!cmd) return;
  try {
    if (isGroup && state.antiLink.get(jid) && /(https?:\/\/|www\.|chat\.whatsapp\.com\/)/i.test(text) && !isOwner(sender)) {
      const admin = await isGroupAdmin(sock, jid, sender);
      if (!admin) return sendText(sock, jid, 'Link detected — please follow the group rules.', msg);
    }
    switch (cmd) {
      case 'menu': case 'help': return sendText(sock, jid, menuText(), msg);
      case 'alive': return sendText(sock, jid, `✅ ${state.botName} is online.\nUptime: ${Math.floor((Date.now() - state.startedAt) / 60000)} minutes\nAI: ${openai ? 'enabled' : 'not configured'}`, msg);
      case 'ping': return sendText(sock, jid, '🏓 Pong!', msg);
      case 'owner': case 'admin': return sendText(sock, jid, `Bot owner: ${process.env.OWNER_NUMBER ? '+' + process.env.OWNER_NUMBER.replace(/\D/g, '') : 'Owner number not configured'}`, msg);
      case 'info': return sendText(sock, jid, `${state.botName}\nWhatsApp MD-style assistant\nPrefix: ${prefix}\nLibrary: Baileys (unofficial)`, msg);
      case 'jid': case 'chatid': return sendText(sock, jid, `Chat ID: ${jid}\nSender ID: ${sender}`, msg);
      case 'setbotpic': case 'setbotpp': case 'setbotprofile': {
        if (!isOwner(sender) && !state.allowPublicProfileChange) return sendText(sock, jid, 'Only the bot owner can change the bot profile picture. The owner may enable public changes in the dashboard, but this is not recommended.', msg);
        if (!state.sock?.user?.id) return sendText(sock, jid, 'WhatsApp is not connected.', msg);
        const buffer = await imageBufferFromMessage(msg);
        if (!buffer) return sendText(sock, jid, `Reply to an image with ${prefix}setbotpic, or send an image with that caption.`, msg);
        const avatar = await sharp(buffer).resize(640, 640, { fit: 'cover' }).webp({ quality: 88 }).toBuffer();
        fs.writeFileSync(path.join(PROFILE_DIR, 'bot-profile.webp'), avatar, { mode: 0o600 });
        await sock.updateProfilePicture(sock.user.id, avatar);
        return sendText(sock, jid, '✅ Bot profile picture updated.', msg);
      }
      case 'setbotname': { if (!isOwner(sender)) return sendText(sock, jid, 'Owner-only command.', msg); if (!arg) return sendText(sock, jid, `Usage: ${prefix}setbotname <name>`, msg); state.botName = arg.slice(0, 40); persistSettings(); await sock.updateProfileName(state.botName).catch(() => {}); return sendText(sock, jid, `Bot name set to ${state.botName}.`, msg); }
      case 'admins': { if (!isGroup) return sendText(sock, jid, 'This command works in groups.', msg); const meta = await sock.groupMetadata(jid); return sendText(sock, jid, '👑 Group admins:\n' + meta.participants.filter(p => p.admin).map(p => '• @' + senderNumber(p.id)).join('\n'), msg); }
      case 'promote': case 'demote': { if (!isGroup) return sendText(sock, jid, 'This command works in groups.', msg); if (!isOwner(sender) && !await isGroupAdmin(sock, jid, sender)) return sendText(sock, jid, 'Only group admins or the owner can use this command.', msg); if (!await isGroupAdmin(sock, jid, sock.user.id)) return sendText(sock, jid, 'Make the bot a group admin first.', msg); const targets = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []; if (!targets.length) return sendText(sock, jid, `Mention a member: ${prefix}${cmd} @user`, msg); await sock.groupParticipantsUpdate(jid, targets, cmd === 'promote' ? 'promote' : 'demote'); return sendText(sock, jid, `Requested ${cmd} action.`, msg); }
      case 'password': { const n = Math.max(8, Math.min(64, Number(args[0]) || 16)); const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%'; const bytes = require('crypto').randomBytes(n); return sendText(sock, jid, '🔐 Random password: ' + Array.from(bytes, b => chars[b % chars.length]).join(''), msg); }
      case 'base64': { const mode = (args[0] || '').toLowerCase(); const value = args.slice(1).join(' '); if (!value || !['encode','decode'].includes(mode)) return sendText(sock, jid, `Usage: ${prefix}base64 encode|decode <text>`, msg); try { return sendText(sock, jid, mode === 'encode' ? Buffer.from(value).toString('base64') : Buffer.from(value, 'base64').toString('utf8'), msg); } catch { return sendText(sock, jid, 'Could not process Base64 input.', msg); } }
      case 'morse': { const mode = (args[0] || '').toLowerCase(); const value = args.slice(1).join(' ').toUpperCase(); const map = {'A':'.-','B':'-...','C':'-.-.','D':'-..','E':'.','F':'..-.','G':'--.','H':'....','I':'..','J':'.---','K':'-.-','L':'.-..','M':'--','N':'-.','O':'---','P':'.--.','Q':'--.-','R':'.-.','S':'...','T':'-','U':'..-','V':'...-','W':'.--','X':'-..-','Y':'-.--','Z':'--..','0':'-----','1':'.----','2':'..---','3':'...--','4':'....-','5':'.....','6':'-....','7':'--...','8':'---..','9':'----.',' ':'/'}; if (!value || !['encode','decode'].includes(mode)) return sendText(sock, jid, `Usage: ${prefix}morse encode|decode <text>`, msg); const rev = Object.fromEntries(Object.entries(map).map(([k,v])=>[v,k])); return sendText(sock, jid, mode === 'encode' ? [...value].map(c=>map[c] || '?').join(' ') : value.split(' ').map(c=>rev[c] || '?').join(''), msg); }
      case 'calc': case 'math': { const expr = arg.trim(); if (!expr || !/^[0-9+*/().%\s-]+$/.test(expr) || /\*\*|\/\//.test(expr)) return sendText(sock, jid, `Usage: ${prefix}calc 12*(4+2)\nOnly basic arithmetic is supported.`, msg); try { const tokens = expr.match(/\d+(?:\.\d+)?|[()+*/%-]/g) || []; if (tokens.join('') !== expr.replace(/\s/g,'')) throw Error(); const result = Function('return (' + expr + ')')(); if (!Number.isFinite(result)) throw Error(); return sendText(sock, jid, `🧮 ${expr} = ${result}`, msg); } catch { return sendText(sock, jid, 'Invalid arithmetic expression.', msg); } }
      case 'toimg': case 'toimage': { const buffer = await imageBufferFromMessage(msg); if (!buffer) return sendText(sock, jid, `Reply to a sticker with ${prefix}toimg.`, msg); const image = await sharp(buffer).png().toBuffer(); return sock.sendMessage(jid, { image, caption: 'Converted by 42 MD BOT' }, { quoted: msg }); }
      case 'sticker': case 's': {
        const buffer = await imageBufferFromMessage(msg);
        if (!buffer) return sendText(sock, jid, `Reply to an image with ${prefix}sticker, or send an image with caption ${prefix}sticker.`, msg);
        const sticker = await sharp(buffer).resize(512, 512, { fit: 'inside', withoutEnlargement: true }).webp({ quality: 82 }).toBuffer();
        return sock.sendMessage(jid, { sticker }, { quoted: msg });
      }
      case 'translate': { const firstSpace = arg.indexOf(' '); if (firstSpace < 1) return sendText(sock, jid, `Usage: ${prefix}translate <language> <text>`, msg); if (!openai) return sendText(sock, jid, 'Translation requires OPENAI_API_KEY in the server environment.', msg); const language = arg.slice(0, firstSpace); const sourceText = arg.slice(firstSpace + 1); const translated = await openai.chat.completions.create({ model: process.env.OPENAI_MODEL || 'gpt-4o-mini', messages: [{ role: 'system', content: `Translate the user's text into ${language}. Return only the translation.` }, { role: 'user', content: sourceText }], max_tokens: 600 }); return sendText(sock, jid, translated.choices?.[0]?.message?.content || 'No translation returned.', msg); }
      case 'rules': return sendText(sock, jid, '📜 Group rules\n1. Respect everyone.\n2. No spam or scams.\n3. Do not share malicious files or links.\n4. Follow the group admins’ instructions.', msg);
      case 'ai': {
        if (!arg) return sendText(sock, jid, `Usage: ${prefix}ai <your question>`, msg);
        if (!openai) return sendText(sock, jid, 'AI is not configured. The owner must add OPENAI_API_KEY to the server environment.', msg);
        const completion = await openai.chat.completions.create({ model: process.env.OPENAI_MODEL || 'gpt-4o-mini', messages: [{ role: 'system', content: 'You are 42 MD BOT, a helpful WhatsApp assistant. Be concise, safe, and clear.' }, { role: 'user', content: arg }], max_tokens: 500 });
        return sendText(sock, jid, completion.choices?.[0]?.message?.content || 'No response received.', msg);
      }
      case 'joke': return sendText(sock, jid, jokes[Math.floor(Math.random() * jokes.length)], msg);
      case 'quote': return sendText(sock, jid, quotes[Math.floor(Math.random() * quotes.length)], msg);
      case 'flip': return sendText(sock, jid, Math.random() < 0.5 ? '🪙 Heads!' : '🪙 Tails!', msg);
      case 'roll': { const n = Math.max(2, Math.min(100, Number(args[0]) || 6)); return sendText(sock, jid, `🎲 You rolled: ${1 + Math.floor(Math.random() * n)} (1–${n})`, msg); }
      case 'rps': { const choices = ['rock', 'paper', 'scissors']; const user = arg.toLowerCase(); if (!choices.includes(user)) return sendText(sock, jid, `Usage: ${prefix}rps rock|paper|scissors`, msg); const bot = choices[Math.floor(Math.random() * 3)]; const result = user === bot ? 'Draw!' : ((user === 'rock' && bot === 'scissors') || (user === 'paper' && bot === 'rock') || (user === 'scissors' && bot === 'paper')) ? 'You win!' : 'I win!'; return sendText(sock, jid, `You: ${user}\n42 MD BOT: ${bot}\n${result}`, msg); }
      case 'groupinfo': { if (!isGroup) return sendText(sock, jid, 'This command works in groups.', msg); const m = await sock.groupMetadata(jid); return sendText(sock, jid, `👥 ${m.subject}\nMembers: ${m.participants.length}\nGroup ID: ${jid}`, msg); }
      case 'tagall': {
        if (!isGroup) return sendText(sock, jid, 'This command works in groups.', msg);
        if (!await isGroupAdmin(sock, jid, sender) && !isOwner(sender)) return sendText(sock, jid, 'Only group admins or the bot owner can use this command.', msg);
        const m = await sock.groupMetadata(jid); const mentions = m.participants.map(p => p.id);
        return sock.sendMessage(jid, { text: `📣 ${arg || 'Attention everyone'}\n\n` + mentions.map(x => '@' + senderNumber(x)).join(' '), mentions }, { quoted: msg });
      }
      case 'kick': {
        if (!isGroup) return sendText(sock, jid, 'This command works in groups.', msg);
        if (!await isGroupAdmin(sock, jid, sender) && !isOwner(sender)) return sendText(sock, jid, 'Only group admins or the bot owner can use this command.', msg);
        if (!await isGroupAdmin(sock, jid, sock.user.id)) return sendText(sock, jid, 'Make the bot a group admin first.', msg);
        const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        if (!mentioned.length) return sendText(sock, jid, `Mention a member: ${prefix}kick @user`, msg);
        await sock.groupParticipantsUpdate(jid, mentioned, 'remove'); return sendText(sock, jid, 'Requested group member removal.', msg);
      }
      case 'antilink': {
        if (!isGroup) return sendText(sock, jid, 'This command works in groups.', msg);
        if (!await isGroupAdmin(sock, jid, sender) && !isOwner(sender)) return sendText(sock, jid, 'Only group admins or the bot owner can use this command.', msg);
        if (!['on', 'off'].includes(args[0])) return sendText(sock, jid, `Usage: ${prefix}antilink on|off`, msg);
        state.antiLink.set(jid, args[0] === 'on'); return sendText(sock, jid, `Anti-link warning ${args[0] === 'on' ? 'enabled' : 'disabled'} for this running session.`, msg);
      }
      default: return;
    }
  } catch (err) {
    logger.error({ err, cmd }, 'Command failed');
    await sendText(sock, jid, 'Sorry, that command failed. Check server logs or try again.', msg).catch(() => {});
  }
}
async function sendText(sock, jid, text, quoted) { return sock.sendMessage(jid, { text: String(text).slice(0, 4000) }, { quoted }); }
async function streamToBuffer(stream) { const chunks = []; for await (const chunk of stream) chunks.push(chunk); return Buffer.concat(chunks); }

async function startWhatsApp() {
  if (state.connecting) return;
  state.connecting = true; state.lastError = null;
  try {
    const { state: authState, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
    let version;
    try { version = (await fetchLatestBaileysVersion()).version; } catch { logger.warn('Could not fetch latest WhatsApp Web version; using library default'); }
    const sock = makeWASocket({ auth: authState, logger: logger.child({ module: 'baileys' }), printQRInTerminal: false, browser: ['42 MD BOT', 'Chrome', '1.0.0'], ...(version ? { version } : {}), markOnlineOnConnect: false, syncFullHistory: false });
    state.sock = sock;
    sock.ev.on('creds.update', saveCreds);
    sock.ev.on('connection.update', update => {
      const { connection, lastDisconnect, qr } = update;
      if (qr) { state.qr = qr; state.pairingCode = null; }
      if (connection === 'open') { state.connected = true; state.connecting = false; state.qr = null; state.pairingCode = null; state.lastConnectedAt = new Date().toISOString(); state.lastError = null; logger.info('WhatsApp connected'); }
      if (connection === 'close') {
        state.connected = false; state.connecting = false;
        const code = lastDisconnect?.error?.output?.statusCode;
        state.lastError = lastDisconnect?.error?.message || 'Connection closed';
        if (code !== DisconnectReason.loggedOut) setTimeout(() => startWhatsApp().catch(err => logger.error(err)), 4000);
        else { state.lastError = 'Logged out. Manual relink required.'; logger.error('WhatsApp logged out; manual relink required'); }
      }
    });
    sock.ev.on('messages.upsert', async ({ messages, type }) => {
      if (type !== 'notify') return;
      for (const msg of messages) {
        if (!msg.message || msg.key.fromMe) continue;
        const body = getText(msg); if (body) await handleCommand(sock, msg, body);
      }
    });
  } catch (err) { state.lastError = err.message; state.connecting = false; logger.error({ err }, 'WhatsApp startup failed'); }
}
startWhatsApp().catch(err => logger.error(err));
app.listen(PORT, HOST, () => logger.info(`42 MD BOT dashboard listening on ${HOST}:${PORT}`));
function shutdown() { logger.info('Shutting down'); try { state.sock?.end(undefined); } catch {} process.exit(0); }
process.on('SIGTERM', shutdown); process.on('SIGINT', shutdown);
