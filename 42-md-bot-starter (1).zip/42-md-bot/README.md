# 42 MD BOT

A self-hostable WhatsApp MD-style bot starter with a private web dashboard, QR linking, optional pairing-code linking, general commands, image-to-sticker conversion, optional AI chat, group tools, and fun commands.

## Important limitations

- This uses **Baileys**, an unofficial WhatsApp Web protocol library. It is not an official WhatsApp/Meta API. WhatsApp may change the protocol or restrict accounts using unofficial automation. Use responsibly and review WhatsApp's terms.
- QR pairing is the primary connection method. Pairing-code availability depends on the installed library and WhatsApp protocol behavior. Never share your QR or pairing code.
- AI requires your own `OPENAI_API_KEY`; API use may cost money.
- Music/video downloading is not shipped as a generic downloader. Add a lawful source/API integration and respect copyright, privacy, and service terms.
- The dashboard uses cookie sessions. Set strong credentials, use HTTPS, and keep it private. For a larger production deployment, add rate limiting, CSRF protection, persistent session storage, and audit logging.
- Use one running bot replica. The WhatsApp auth folder must be on durable storage or you may need to relink after restarts.

## Local setup

1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env` and fill in `OWNER_NUMBER`, `ADMIN_USERNAME`, `ADMIN_PASSWORD`, and `ADMIN_SESSION_SECRET`. Use a password of at least 12 characters and a random session secret of at least 32 characters.
3. Install and start:

   ```bash
   npm install
   npm start
   ```

4. Open `http://localhost:3000`, sign in, and scan the QR using WhatsApp → Linked devices → Link a device.
5. To try pairing-code linking instead, enter your own phone number in international format without `+`, then click **Request pairing code**. If it fails, use QR linking.

## Railway deployment

1. Create a private GitHub repository and push these project files to its `main` branch.
2. In Railway, create a project and deploy the GitHub repository as a service.
3. Add a Railway **Volume** mounted at `/data`. Set `DATA_DIR=/data`. This keeps WhatsApp credentials across restarts.
4. Add these service variables in Railway:
   - `NODE_ENV=production`
   - `DATA_DIR=/data`
   - `BOT_NAME=42 MD BOT`
   - `PREFIX=.`
   - `OWNER_NUMBER` — your own number in international format, digits only
   - `ADMIN_USERNAME` — a username you choose
   - `ADMIN_PASSWORD` — a long, unique password (12+ characters)
   - `ADMIN_SESSION_SECRET` — a random secret of 32+ characters
   - `OPENAI_API_KEY` and optionally `OPENAI_MODEL` if enabling AI
   - Railway supplies `PORT`; do not hard-code another port
5. Generate a public domain for the service, open it over HTTPS, sign in, and scan the QR.
6. Keep one replica. Do not share the dashboard URL publicly without protecting access. Never publish `.env` or the WhatsApp auth files.
7. Check `/health` and Railway logs after deployment.

## Commands

See [`COMMAND_CATALOG.md`](COMMAND_CATALOG.md) for the combined catalogue and a clear distinction between commands implemented in this build and commands that still need integrations. Implemented commands include `.menu`, `.alive`, `.ping`, `.owner`, `.info`, `.jid`, `.sticker`, `.ai`, `.setbotpic`, `.setbotname`, `.groupinfo`, `.admins`, `.tagall`, `.kick`, `.promote`, `.demote`, `.antilink`, `.calc`, `.base64`, `.morse`, `.password`, `.joke`, `.quote`, `.flip`, `.roll`, and `.rps`.

## Owner dashboard and profile picture

- Sign in with `ADMIN_USERNAME` and `ADMIN_PASSWORD` over HTTPS.
- The dashboard can request QR/pairing-code linking, edit the bot display name and prefix, and upload a bot profile picture.
- Settings are stored under `DATA_DIR/settings.json`; profile image files are stored under `DATA_DIR/profile/`. Mount `DATA_DIR` on persistent storage (Railway Volume at `/data`).
- `.setbotpic` / `.setbotpp`: reply to an image with the command, or send an image with the command as its caption. Only the configured owner can use it by default.
- The dashboard has an opt-in switch to let any chat user change the bot's global profile picture. Keep it disabled unless you deliberately want this risk: a user can replace the picture for everyone.
- Pairing connects the **bot owner's WhatsApp account** to the service. It is not a separate account for every visitor; only the owner should access the private dashboard. Do not publish QR codes or pairing codes.

Group tools require appropriate WhatsApp group permissions. The current anti-link feature only warns and is not a complete anti-link enforcement system. Some listed catalogue items need APIs or more implementation; they are not falsely presented as ready-to-use commands.
